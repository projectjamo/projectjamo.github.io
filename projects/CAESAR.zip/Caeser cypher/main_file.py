# -*- coding: utf-8 -*-
"""
Created on Tue Dec  8 09:50:24 2020

@author: jamie
"""

from encrypt import encryptor 
from decrypt import decryptor
import random
from analytical_functions import Analyse
#importing functions to encrypt or decrypt the message


print("Hello and welcome to Jamie's Caeser cipher")




enc_or_dec = input("Are we encoding or decoding? (encoding/decoding) ").lower()
#PART 1.1
#everything is made lower case so that the code can recognise the input
#even if the user is using capitals

while str(enc_or_dec)!="encoding" and str(enc_or_dec)!="decoding":
    print("That is not a valid input")
    enc_or_dec = input("Are we encoding or decoding? (encoding/decoding) ").lower()
    #PART 1.2: Checks if the input is either of the words we accept and repeats the
    #question if not
    
if str(enc_or_dec) == "encoding":
    shift = (input("How many spaces forward do you want to shift by? If you "
                   +"want to shift by a random number please input the "
                   +"word 'random'.")).lower()
    #PART 1.1: Asks the user for our rotation value. We make the value lower case
    #just so that if the user types random with capital letters it is still accepted
    
    while shift.isdigit() == False and shift != "random":
        print("Sorry, only numbers or the word 'random' are accepted in this field")
        shift = (input("How many spaces forward do you want to shift by? ")).lower()
        #PART 1.2: This part of the code only accepts numbers or the word random as inputs
        #so if the input is not a number then the question is repeated
        
    if shift == "random":
        shift = random.randint(1,25)
        #PART 1.6: If the input is random, then we give shift a random value 
        #between 1 and 25
    else:
        shift = int(shift)
    message = input("What is the message you want to encrypt? ").lower()
    #PART 1.1: This is where the user inputs the message they want encrypted
    print("Here is your encoded message: ")
    encrypted = (encryptor((shift),message).upper())
    output = message
    #PART 1.3: Puts the user input into the encryptor function
    print(encrypted)
    #PART 1.5: Prints the encrypted message
    

if str(enc_or_dec) == "decoding":
    q1 = input("Do we know how many spaces to the right the message"+
               " has been shifted by? (Y/N)").upper()
    #PART 1.1: Asks if we know the rotation value so the program
    #knows what to do next
    while q1 !="Y" and q1 !="N": 
        print("Please either reply with 'Y' or 'N'.")
        q1 = input("Do we know how many spaces to the right the message"+
               " has been shifted by? (Y/N)").upper()
    #PART 1.2: Makes sure that only acceptable inputs make it through
    
    if q1 == "Y":
        shift = (input("How many spaces has the message been shifted by? "))
        #PART 1.1: Asks for our rotation value
        
        while shift.isdigit() == False:
            print("Sorry, only numbers are accepted in this field")
            shift = (input("How many spaces has the message been shifted by? "))
            #PART 1.2: Repeats the question if invalid input is given
            
        message = input("Please input the encoded message you would like to decrypt: ")
        #PART 1.1: This is where the user puts the message they want decrypted
        print("Here is your decoded message: ")
        output = (decryptor(int(shift),message).upper())
        #PART 1.4: Puts the user input into the decryptor function
        print(output)
        #PART 1.5: Prints the decrypted message
    if q1 == "N":
        q2 = input("Would you like to use the auto decryptor or choose "+
                   "which decryption is correct manually? (auto/manu)").upper()
        #PART 4.1: The option to either select the correct answer manually
        #from a stack of decrypted messages or use the auto decryptor.
        while q2 !="AUTO" and q2!="MANU":
            print("That is not a valid input, please reply with either"+
                  " 'auto' or 'manu'.")
            q2 = input("Would you like to use the auto decryptor or choose "+
                   "which decryption is correct manually? (auto/manu)").upper()
        #PART 1.2: Makes sure that if a valid input is not given we ask the user to try again
        
        if q2 == "MANU":
            message = input("Please input the message you would like to decrypt: ")
            print("Here is a list of possible decriptions of the message,"+
                  "the number before the line is the number of positions"+
                  " the message has been shifted by.")
            
            shorter_message = []
            z = 0
            for i in range(len(message.split())):
                shorter_message.append(message.split()[z])
                z+=1
            joined_shorter_message = ' '.join(shorter_message)
            
            
            n=0
            for shift in range(26):
                print(n,')',decryptor(shift,joined_shorter_message).upper())
                print("")
                n+=1
            
            correct_line = input("Please type in the number of the line with "+
                             "the correct decryption of the message: ")
            while correct_line.isdigit() == False or int(correct_line)>25 or int(correct_line)<0:
                print("Please input a valid number.")
                correct_line = input("Please type in the number of the line with"+
                                     " the correct decryption of the message")
                #PART 1.2: Making sure the user can only enter valid inputs. If they 
                #dont then the question is repeated.
            
            output = decryptor(int(correct_line),message)
            
        if q2 == "AUTO":
            message = input("Please input the message you would like to decrypt: ")
            print("")
            
            shorter_message = []
            n = 0
            for i in range(len(message.split())):
                shorter_message.append(message.split()[n])
                n+=1
            joined_shorter_message = ' '.join(shorter_message)
            #PART 4.3: Makes it so that the user only sees the first line
            #of the decrypted code to save time
            list_words = []
            file = open("words.txt","r")
            for line in file:
                split_line = line.split()
                list_words.append(''.join(split_line).upper())
            file.close()
            #PART 4.2: Program reads the text file and puts all the elements into a list
            
            shift = 0
            correct_decryption = "N"
            
            
            while correct_decryption == "N" and shift < 26:
                list_decryption = (decryptor(shift,joined_shorter_message).upper()).split()
                #PART 4.3 Here we are rotating through all possible decryptions of the message
                y = 0 
                for element in list_decryption:
                    if element in list_words and y<1:
                        #PART 4.3 If we have found a match we ask the user if this is correct
                        #If the user answers no the code just repeats, the y<1 y+=1 code is
                        #there to make sure that if there are multiple matches in a possible
                        #decryption that isnt the correct one, the user only has to say no once
                        y+=1
                        print((decryptor(shift,joined_shorter_message)).upper()+"...")
                        correct_decryption = input("Is this the correct decryption? (Y/N)").upper()
                        while correct_decryption != "Y" and correct_decryption != "N":
                            print("That is not a valid input, please type either 'Y' or 'N'")
                            print("")
                            print((decryptor(shift,joined_shorter_message)).upper()+"...")
                            correct_decryption = (input("Is this the correct decryption? (Y/N)")).upper()
                       #PART 1.2: Makes sure we only accept valid inputs from the user, or we ask them again.
                        if correct_decryption == "Y":
                            output = decryptor(shift,message)
                            print("This is the correct decryption for the message:")
                            print(output.upper())
                            #PART 4.3 if the user answers yes, output is set as the message the user said yes to.
                            
                shift+=1
                if correct_decryption == "N" and shift == 25:
                    print("No decryption could be found for this message")
                    output = ""
            
if len(output)>0:        
    print(" ")
    print("Below this line are the analytics of the message")
    print("------------------------------------------------")
    output_analyse = (Analyse(output))
    
    file = open("analytics.txt","w")
    
    print("Number of words in the message:",output_analyse.wcounter)
    file.write("Words: "+str(output_analyse.wcounter)+"\n")
    #PART 2.2 AND PART 2.3: Each line of code here is displaying the information given
    #by the relevant function of the Analyse class we created. After this, the same
    #information is written to a file called analytics.txt. 
    
    print("Number of unique words in this message:",output_analyse.uwcounter)
    file.write("Unique words: "+str(output_analyse.uwcounter)+"\n")
    
    print("Most common letter in the message: "+(output_analyse.cletters[0]).upper()+" with "
          +str(output_analyse.cletters[1])+" uses.")
    
    print("Longest word: "+(output_analyse.maxmin[0]).upper()+" with "
          +str(output_analyse.maxmin[1])+" letters.")
    file.write("Max word length: "+str(output_analyse.maxmin[1])+"\n")
    
    
    print("Shortest word: "+(output_analyse.maxmin[2]).upper()+" with "
          +str(output_analyse.maxmin[3])+" letter(s).")
    file.write("Min word length: "+str(output_analyse.maxmin[3]))
    
    file.close()
    
    if output_analyse.uwcounter >=10:
        print("Here are the top ten most common words in the message: ")
        n=0
        for element in output_analyse.cwords:
            print(element)
            n+=1
            if n >=10:
                break
    else:
        print("Here are the most common words in the message: \n")
        for element in output_analyse.cwords:
            print(element)
            #PART 2.2: For the parts where we are printing common words and their frequency, we use
            #a for loop because our function creates a list with the format frequency : word.
    #PART 2.2 and PART 2.3: All the code above this comment and below the line is dedicated
    #to just printing out the analytics of the message and writing that to the file