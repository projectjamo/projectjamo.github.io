# -*- coding: utf-8 -*-
"""
Created on Tue Dec  1 20:29:34 2020

@author: jamie
"""
from alphabet import alpha_list

def single_word_coder(shift,word): 
    word_list = list(word)
    pos=0
    
    for letter in word_list:
        if letter not in alpha_list:
            break
        
        alpha_index = alpha_list.index(letter)
        if alpha_index+shift>25:
            word_list[pos]=alpha_list[alpha_index+shift-26]
        else:
            word_list[pos]=alpha_list[alpha_index+shift]
        pos+=1
    
    return ''.join(word_list)

def encryptor(shift,message):
    list_inputs = message.lower().split()
    pos = 0
    for word in list_inputs:
       list_inputs[pos] = single_word_coder(shift,word)
       pos+=1
    return ' '.join(list_inputs)
        


