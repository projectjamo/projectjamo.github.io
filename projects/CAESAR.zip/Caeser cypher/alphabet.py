# -*- coding: utf-8 -*-
"""
Created on Tue Dec  1 20:28:25 2020

@author: jamie
"""

alpha_list = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p"
              ,"q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H",
              "I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
#PART 1.1: list of all the letters in the alphabet so we can find the index of a letter
#later