# -*- coding: utf-8 -*-
"""
Created on Wed Dec  9 23:03:20 2020

@author: jamie
"""
from collections import Counter
from alphabet import alpha_list

def punctuation_remover (word):
    word_list = list(word)
    corrected_word = []
    
    for letter in word_list:
        if letter in alpha_list:
            corrected_word.append(letter)
    
    return ''.join(corrected_word)
    #PART 2.1: Removes anything that is not a letter from a word, normalises them.


def word_counter(output):
    corrected_output = []
    
    for word in output.split(' '):
        corrected_output.append(punctuation_remover(word))
    
    n = len(corrected_output)
    
    for element in corrected_output:
        if element == '':
            n-=1
   
    return n
    #PART 2.1: Normalises all the words, if something is not a word
    #it becomes an empty element in the list of words, so we count up
    #all the elements in the list and subtract the number of empty elements
    

def unique_word_counter(output):
    n = 0
    output_words = output.split(' ')
    corrected_output = []
    unique_words = []
    
    for word in output_words:
        corrected_output.append(punctuation_remover(word))
    
    for word in corrected_output:
        if word in unique_words:
            n=n
        else:
            unique_words.append(word)
            n+=1
    if '' in unique_words:
        n-=1
    #if there is a single character of punctuation on its own, it will show up
    #as '' in the list, this line of code removes that from the count.
    return n
    #PART 2.1: Does the same process as word_counter, but adds elements to a
    #list and omits any repeat words




def common_letters (output):
    output_list = list(output)
    corrected_list = []
    n = 0
    for char in output_list:
        if char in alpha_list:
            corrected_list.append(char)        
    for letter in corrected_list:
        if Counter(corrected_list)[letter] > n:
            n = Counter(corrected_list)[letter]
            mcl = letter
    return mcl, n
    #PART 2.1: Makes a list of all the letters in the message, then uses the Counter
    #class to find which one has the most instances
    
    
def max_and_min_word_length(output):
    n = 0 
    m = 1000
    output_list = output.split(' ')
    corrected_output = []
    for word in output_list:
        corrected_output.append(punctuation_remover(word))
    for word in corrected_output:
        if len(word) > n:
            n = len(word)
            max_word = word
        if len(word) < m and len(word)>0:
            m = len(word)
            min_word = word
    return max_word,n, min_word,m
    #PART 2.1: Normalises all the words then uses a loop to find which word is the largest
    #and which word is the smallest
    #the second if statement has the condition of being >0 so that empty elements in the
    #list are ignored (these can be created by numbers)


def word_count (output):
    output_words = output.split(' ')
    corrected_output = []
    for word in output_words:
        corrected_output.append(punctuation_remover(word))
    
    word_count = (Counter(corrected_output))
    return word_count
    #PART 2.1: A prerequisite to the common_words function. This function counts
    #how many times a word is in a list after using the punctuation remover to 
    #normalise the words.


def common_words(output):
    corrected_output = []
    freq_and_word = []
    for word in output.split(' '):
        corrected_output.append(punctuation_remover(word))
        #Using the punctuation remover to normalise all words
    for word in corrected_output:
        freq_and_word.append(str(word_count(output)[word])+' : '+word.upper())
    sorted_output = sorted(freq_and_word,reverse=True)
    unique_sorted_output = []
    for element in sorted_output:
        if element not in unique_sorted_output:
            unique_sorted_output.append(element)
    return unique_sorted_output
    #PART 2.1: uses the punctuation remover to create a list, then creates a list
    #of words and their corresponding frequencies, but there are repeating elements
    #so we then create another list, this time with only the unique elements.

class Analyse:
    def __init__(self,output):
        self.cletters = common_letters(str(output))
        self.cwords = common_words(output)
        self.uwcounter = unique_word_counter(str(output))
        self.wcounter = word_counter(str(output))
        self.maxmin = max_and_min_word_length(output)
        #PART 2.2: Class makes it easier to import all of these functions into the main file, 
        #making the code easier to read. 
        













